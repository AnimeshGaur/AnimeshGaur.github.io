 <!DOCTYPE html>
<html lang="en">
<head>
<title>Privacy Policy</title>
</head>
<body>
 <!DOCTYPE html>
<html lang="en">
<head>
<title>eWeb Services Pvt. Ltd.</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Archivo:400,400i,500,600,700" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="css/plan.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<header>
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 phone">
					<a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a>
				</div>
				<div class="col-md-4 col-sm-4 email">
					<a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="top_social">
						<ul>
							<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
							<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						</button>
					   <div class="logo"><a href="index.php"><img src="images/logo.png" alt="logo"></a></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.php">Home</a></li>
							<li><a href="about-us.php">About Us</a></li>
								<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services 
									<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="website-design.php">Website Designing</a></li>
										<li><a href="web-development.php">Web Development</a></li>
										<li><a href="wordpress-development.php">Wordpress Development</a></li>
										<li><a href="ecommerce-solutions.php">Ecommerce Solutions</a></li>
										<!--<li class="spcial"><a href="special-website-offers.php">Special Website Offers</a></li>-->
										<li><a href="mobile-apps-development.php">Mobile Apps Development</a></li>
																				
										<li><a href="digital-marketing.php">Digital Marketing</a></li>
										<li class="bordn"><a href="web-hosting.php">Web Hosting</a></li>
									</ul>					
								</li>
							<li><a href="portfolio.php">Portfolio</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3">
					<div class="anm_boxx">
						<a href="contactus.php">Request Callback</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
</header>

<!--
<div class="modal fade show in" id="myModal1" role="dialog" aria-modal="true">
  <div class="modal-dialog"> 
    <div class="modal-content">
      <div class="modal-body inq-form">
        <button type="button" class="close btn-white" data-dismiss="modal">×</button>
              <section class="content">
                	<div class="container">
                		<div class="row">
                			<div class="col-md-6 col-sm-6 contt">
                				<h2>Get in Touch With us</h2>
                                        <form name="contactform" method="post" action="contact.php">
                                            <table width="100%">
                                                 <tr>
                                                     <td valign="top">
                                                        <label for="name">Name *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="name" maxlength="50" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="email">Email *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="email" maxlength="80" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                         <label for="phone">Phone *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="phone" maxlength="30" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="comments">Message *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <textarea  name="message" maxlength="1000" cols="25" rows="6" required></textarea>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td colspan="2" style="text-align:center">
                                                        <input type="submit" value="Submit" class="btn btn-primary bttnns">
                                                     </td>
                                                </tr>
                                            </table>
                                        </form>
                			</div>
                		</div>		
                	</div>
                </section>
            </div>
          </div>
        </div>
      </div>

//JS FILES
<script src="js/jquery.min.js"></script> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/swiper.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/jquery.stellar.js"></script> 
<script src="js/isotope.min.js"></script> 
<script src="js/scripts.js"></script> 
<script src="js/viewer.js"></script> 
<script src="js/jquery-viewer.js"></script> 
<script src="js/main.js"></script> 
<script src="js/jquery.cookie.min.js"></script>
<script src="js/form-scripts.js"></script>
-->

</body>
</html> <div class="banner">
	<img src="images/privacy-policy.jpg">
</div>
<!-- content_section -->


<section class="content">
	<div class="container">	
		<div class=""></div>
		<div class="col-md-12">
			<h2>Privacy Policy</h2>
			<p>If you are using our services, you should get in touch with us always:
www.ewebservices.co.uk is operated and owned by eWeb Services. We are working as an independent company, assuring for the extensive solutions in areas of multimedia productions, web application, & technology talk.</p>

<h1>Website Content</h1>

<p>The client is accountable to supply and/or find the rights and even approval for any context or pictures to be utilized on the website. The client will not hinder upon eWeb Services to employ “pirated” software or appoint in any denotes of plagiarism.  eWeb Services Company and client should together clear any third party attachment in the web portal. The website might be using the third party elements. We have no managed over what third-party websites perform and take no accountability for loss of information owed to actions of these websites.</p>

<p>The content of the site should be offered electronically as much as easy. Accessories’ should be in text design (.txt or Word .doc formats are okay). Send digitized images in ordinary format which includes .jpg, .gif, .bmp, .ai, .psd and .png etc. One should have updates might also be sent by postal mail. This will need retyping information or the scanning of images and will cost more to absolute your changes.</p>

<p>At eWeb Services, we make sure that our clients that no division of their work will be negotiated, disclosed to somebody, or shared with anybody for any reason whatever. The work is 100% safe with us and will remain your work completely. </p>

<h1>Collection of Personal Information and Use</h1>
<p>We esteem each site visitor’s right to individual retreat. To that end, we gather and use information just as revealed in this Privacy Policy. We collect name, email, phone number, address, comments and profession for posting. We just use your email address to get in touch with you for a respond. We are not accountable for the personally particular information you select to submit in the forums.</p>

<h1>Cookies</h1>
<p>A cookie is a little text file that is stored on a user’s PC for record-keeping reasons. We perform set cookies on this website. Meanwhile, many of the business partners may use cookies on our website. The company has no access to or even directly over these cookies.</p>

<h1>Payments</h1>
<p>You can ideally make choice from Online Transfer, Demand Draft or Cheque for settling down the payments. No sensitive or even personal information is ever requested on our Web site apart from information gathered for billing reasons and even order execution and not for purposes of marketing.</p>

<h1>Communications from the Site</h1>
If you have some queries in your mind related to our services, you can write down an email to us, our team will make a reply as quickly as possible. </p>

<h1>Testimonials</h1>
<p>Our team post testimonials of the client on the testimonial page of the website. We get permission to post the testimonials before the posting. </p>

<h1>Sharing</h1>
<p>We promise not to share any sort of personally identifiable information composed on our Web site with any third parties for any reason which include marketing.</p>

<h1>Links to Other Sites</h1>
<p>This Website possesses links to similar sites that are not handled or even controlled by eWeb Services. Please be alert that we, eWeb Services, are not accountable for the privacy practices of similar websites. </p>

<h1>Confidential Information / Data Security</h1>
<p>The company is committed to making sure that the information of the user is secure. In order to avoid unauthorized access or even discovery, we have put in place appropriate physical, electronic and executive process to defend and secure the information we gather online. We will not distribute, sell, or lease your personal details to third parties unless we have your authorization or are necessary by law to perform so. We might use the personal information to drive the promotional information related to third parties which we think you may discover interesting if you inform us that you desire this to happen.</p>

<h1>Policy for Content and Anti-Spam</h1>
<p>eWeb Services Web Development and design services, domains and sub-domains owned and operated by eWeb Services shall follow to an exacting NO SPAM policy. In the case, SPAM comprises but is not restricted to the sending of unwelcome or bulk business e-mail and posting ads in the groups of news or even message boards when the action is stopped or message is off-topic and unconnected.</p>

<h1>Contact Information</h1>
<p>If you are interested in the services offered by eWeb Services and wish to collect more information, you can pick your phone and dial +91-959-974-1924. You can also write an email to our expert on info@ewebservices.co.uk. All of the queries get resolved quickly. Contact us now!</p>
		</div>					
	</div>
</section>
<!--// top_section -->
 <!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>

<!-- footer -->
<footer>
	<div class="container">
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Quick Link</h3>
				<ul class="foot_link">
					<li><a href="about-us.php"><i class="fa fa-angle-right"></i> About Us</a></li>
					<li><a href="portfolio.php"><i class="fa fa-angle-right"></i> Portfolio</a></li>
					<li><a href="privacy-policy.php"><i class="fa fa-angle-right"></i> Privacy Policy</a></li>
					<li><a href="contactus.php"><i class="fa fa-angle-right"></i> Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Contact Details</h3>
				<ul class="foot_link">
				    <li><strong>INDIA OFFICE</strong></li>
					<li><i class="fa fa-home"></i> A-16 Sector-9 Noida U.P. -201301, INDIA</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
					<br>
					<li><strong>US OFFICE</strong></li>
					<li><i class="fa fa-home"></i> 20 Days Ave selden NY 12784</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i> +1-631-965-9106</a></li>
					
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Web Services</h3>
				<ul class="foot_link">
					<li><a href="website-design.php"><i class="fa fa-angle-right"></i> Website Designing</a></li>
					<li><a href="web-development.php"><i class="fa fa-angle-right"></i> Web Development</a></li>
					<li><a href="wordpress-development.php"><i class="fa fa-angle-right"></i> Wordpress Development</a></li>
					<li><a href="ecommerce-solutions.php"><i class="fa fa-angle-right"></i> Ecommerce Solutions</a></li>
					<li><a href="mobile-apps-development.php"><i class="fa fa-angle-right"></i> Mobile Apps Development</a></li>
					<li><a href="digital-marketing.php"><i class="fa fa-angle-right"></i> Digital Marketing</a></li>
					<li><a href="web-hosting.php"><i class="fa fa-angle-right"></i> Web Hosting</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Connect With Us</h3>
				<ul class="social_link">
					<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
					<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>Copyright <i class="fa fa-copyright"></i> 2020 <a href="http://www.ewebservices.co.uk/">eWeb Services</a> All rights reserved</p>
		</div>
	</div>
</footer>
<!--// footer -->
<!-- js -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
	(function( $ ) {

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#carousel-example-generic'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
    $('#carousel-example-generic').carousel({
        interval:3000,
        pause: "false"
    });
	
})(jQuery);	
</script>

<a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" title="" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>

<script>
  $(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});
</script>

</body>
</html> </body>
</html> 
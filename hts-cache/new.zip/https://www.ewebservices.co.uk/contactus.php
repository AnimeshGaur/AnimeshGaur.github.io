 <!DOCTYPE html>
<html lang="en">
<head>
<title>Contact Us - eWeb Services Pvt. Ltd.</title>
</head>
<body>
 <!DOCTYPE html>
<html lang="en">
<head>
<title>eWeb Services Pvt. Ltd.</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Archivo:400,400i,500,600,700" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="css/plan.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<header>
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 phone">
					<a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a>
				</div>
				<div class="col-md-4 col-sm-4 email">
					<a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="top_social">
						<ul>
							<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
							<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						</button>
					   <div class="logo"><a href="index.php"><img src="images/logo.png" alt="logo"></a></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.php">Home</a></li>
							<li><a href="about-us.php">About Us</a></li>
								<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services 
									<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="website-design.php">Website Designing</a></li>
										<li><a href="web-development.php">Web Development</a></li>
										<li><a href="wordpress-development.php">Wordpress Development</a></li>
										<li><a href="ecommerce-solutions.php">Ecommerce Solutions</a></li>
										<!--<li class="spcial"><a href="special-website-offers.php">Special Website Offers</a></li>-->
										<li><a href="mobile-apps-development.php">Mobile Apps Development</a></li>
																				
										<li><a href="digital-marketing.php">Digital Marketing</a></li>
										<li class="bordn"><a href="web-hosting.php">Web Hosting</a></li>
									</ul>					
								</li>
							<li><a href="portfolio.php">Portfolio</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3">
					<div class="anm_boxx">
						<a href="contactus.php">Request Callback</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
</header>

<!--
<div class="modal fade show in" id="myModal1" role="dialog" aria-modal="true">
  <div class="modal-dialog"> 
    <div class="modal-content">
      <div class="modal-body inq-form">
        <button type="button" class="close btn-white" data-dismiss="modal">×</button>
              <section class="content">
                	<div class="container">
                		<div class="row">
                			<div class="col-md-6 col-sm-6 contt">
                				<h2>Get in Touch With us</h2>
                                        <form name="contactform" method="post" action="contact.php">
                                            <table width="100%">
                                                 <tr>
                                                     <td valign="top">
                                                        <label for="name">Name *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="name" maxlength="50" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="email">Email *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="email" maxlength="80" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                         <label for="phone">Phone *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="phone" maxlength="30" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="comments">Message *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <textarea  name="message" maxlength="1000" cols="25" rows="6" required></textarea>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td colspan="2" style="text-align:center">
                                                        <input type="submit" value="Submit" class="btn btn-primary bttnns">
                                                     </td>
                                                </tr>
                                            </table>
                                        </form>
                			</div>
                		</div>		
                	</div>
                </section>
            </div>
          </div>
        </div>
      </div>

//JS FILES
<script src="js/jquery.min.js"></script> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/swiper.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/jquery.stellar.js"></script> 
<script src="js/isotope.min.js"></script> 
<script src="js/scripts.js"></script> 
<script src="js/viewer.js"></script> 
<script src="js/jquery-viewer.js"></script> 
<script src="js/main.js"></script> 
<script src="js/jquery.cookie.min.js"></script>
<script src="js/form-scripts.js"></script>
-->

</body>
</html> <div class="banner">
	<img src="images/contact-us.jpg">
</div>
<!-- content_section -->
<section class="content">
	<div class="container">
		<div class="row">
			<h1 class="title">Get in Touch With us</h1>
			<div class="col-md-6 col-sm-6 contt">
				<h2>Let's Talk Business!</h2>

<!----			Contact form Start -------->
                        <form name="contactform" method="post" action="contact.php">
                            <table width="100%">
                            <tr>
                             <td valign="top">
                              <label for="name">Name *</label>
                             </td>
                             <td valign="top">
                              <input  type="text" name="name" maxlength="50" size="30" required>
                             </td>
                            </tr>
                            <!--<tr>
                             <td valign="top"">
                              <label for="last_name">Last Name *</label>
                             </td>
                             <td valign="top">
                              <input  type="text" name="last_name" maxlength="50" size="30">
                             </td>
                            </tr>-->
                            <tr>
                             <td valign="top">
                              <label for="email">Email *</label>
                             </td>
                             <td valign="top">
                              <input  type="text" name="email" maxlength="80" size="30" required>
                             </td>
                            </tr>
                            <tr>
                             <td valign="top">
                              <label for="phone">Phone *</label>
                             </td>
                             <td valign="top">
                              <input  type="text" name="phone" maxlength="30" size="30" required>
                             </td>
                            </tr>
                            <tr>
                             <td valign="top">
                              <label for="comments">Message *</label>
                             </td>
                             <td valign="top">
                              <textarea  name="message" maxlength="1000" cols="25" rows="6" required></textarea>
                             </td>
                            </tr>
                            <tr>
                             <td colspan="2" style="text-align:center">
                              <input type="submit" value="Submit" class="btn btn-primary bttnns">
                             </td>
                            </tr>
                            </table>
                        </form>
<!----			Contact form End -------->

			</div>
			<div class="col-md-6 col-sm-6 contt">
				<h2>Offices and Locations</h2>
				
				<ul class="add_list">
					<li><strong>INDIA OFFICE</strong></li>
					<li><i class="fa fa-home"></i> A-16 Sector-9 Noida U.P. -201301, INDIA</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
					<br>
					<li><strong>US OFFICE</strong></li>
					<li><i class="fa fa-home"></i> 20 Days Ave selden NY 12784</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i> +1-631-965-9106</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
				</ul>
				
				<div class="map">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28025.558912328204!2d77.31233339506781!3d28.59393040722875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5c58b261a07%3A0x26843e1f42e36be2!2seWeb%20Services%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1609178580743!5m2!1sen!2sin" width="100%" height="180" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
			</div>
		</div>		
	</div>
</section>
<!--// top_section -->
 <!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>

<!-- footer -->
<footer>
	<div class="container">
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Quick Link</h3>
				<ul class="foot_link">
					<li><a href="about-us.php"><i class="fa fa-angle-right"></i> About Us</a></li>
					<li><a href="portfolio.php"><i class="fa fa-angle-right"></i> Portfolio</a></li>
					<li><a href="privacy-policy.php"><i class="fa fa-angle-right"></i> Privacy Policy</a></li>
					<li><a href="contactus.php"><i class="fa fa-angle-right"></i> Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Contact Details</h3>
				<ul class="foot_link">
				    <li><strong>INDIA OFFICE</strong></li>
					<li><i class="fa fa-home"></i> A-16 Sector-9 Noida U.P. -201301, INDIA</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
					<br>
					<li><strong>US OFFICE</strong></li>
					<li><i class="fa fa-home"></i> 20 Days Ave selden NY 12784</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i> +1-631-965-9106</a></li>
					
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Web Services</h3>
				<ul class="foot_link">
					<li><a href="website-design.php"><i class="fa fa-angle-right"></i> Website Designing</a></li>
					<li><a href="web-development.php"><i class="fa fa-angle-right"></i> Web Development</a></li>
					<li><a href="wordpress-development.php"><i class="fa fa-angle-right"></i> Wordpress Development</a></li>
					<li><a href="ecommerce-solutions.php"><i class="fa fa-angle-right"></i> Ecommerce Solutions</a></li>
					<li><a href="mobile-apps-development.php"><i class="fa fa-angle-right"></i> Mobile Apps Development</a></li>
					<li><a href="digital-marketing.php"><i class="fa fa-angle-right"></i> Digital Marketing</a></li>
					<li><a href="web-hosting.php"><i class="fa fa-angle-right"></i> Web Hosting</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Connect With Us</h3>
				<ul class="social_link">
					<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
					<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>Copyright <i class="fa fa-copyright"></i> 2020 <a href="http://www.ewebservices.co.uk/">eWeb Services</a> All rights reserved</p>
		</div>
	</div>
</footer>
<!--// footer -->
<!-- js -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
	(function( $ ) {

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#carousel-example-generic'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
    $('#carousel-example-generic').carousel({
        interval:3000,
        pause: "false"
    });
	
})(jQuery);	
</script>

<a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" title="" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>

<script>
  $(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});
</script>

</body>
</html> 
</body>
</html> 
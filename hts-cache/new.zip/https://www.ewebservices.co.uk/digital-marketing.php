 <!DOCTYPE html>
<html lang="en">
<head>
<title>Digital Marketing - Google Adwords (PPC) | SEO Services INDIA, Delhi.</title>
</head>
<body>
 <!DOCTYPE html>
<html lang="en">
<head>
<title>eWeb Services Pvt. Ltd.</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Archivo:400,400i,500,600,700" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="css/plan.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<header>
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 phone">
					<a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a>
				</div>
				<div class="col-md-4 col-sm-4 email">
					<a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="top_social">
						<ul>
							<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
							<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						</button>
					   <div class="logo"><a href="index.php"><img src="images/logo.png" alt="logo"></a></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.php">Home</a></li>
							<li><a href="about-us.php">About Us</a></li>
								<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services 
									<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="website-design.php">Website Designing</a></li>
										<li><a href="web-development.php">Web Development</a></li>
										<li><a href="wordpress-development.php">Wordpress Development</a></li>
										<li><a href="ecommerce-solutions.php">Ecommerce Solutions</a></li>
										<!--<li class="spcial"><a href="special-website-offers.php">Special Website Offers</a></li>-->
										<li><a href="mobile-apps-development.php">Mobile Apps Development</a></li>
																				
										<li><a href="digital-marketing.php">Digital Marketing</a></li>
										<li class="bordn"><a href="web-hosting.php">Web Hosting</a></li>
									</ul>					
								</li>
							<li><a href="portfolio.php">Portfolio</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3">
					<div class="anm_boxx">
						<a href="contactus.php">Request Callback</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
</header>

<!--
<div class="modal fade show in" id="myModal1" role="dialog" aria-modal="true">
  <div class="modal-dialog"> 
    <div class="modal-content">
      <div class="modal-body inq-form">
        <button type="button" class="close btn-white" data-dismiss="modal">×</button>
              <section class="content">
                	<div class="container">
                		<div class="row">
                			<div class="col-md-6 col-sm-6 contt">
                				<h2>Get in Touch With us</h2>
                                        <form name="contactform" method="post" action="contact.php">
                                            <table width="100%">
                                                 <tr>
                                                     <td valign="top">
                                                        <label for="name">Name *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="name" maxlength="50" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="email">Email *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="email" maxlength="80" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                         <label for="phone">Phone *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="phone" maxlength="30" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="comments">Message *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <textarea  name="message" maxlength="1000" cols="25" rows="6" required></textarea>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td colspan="2" style="text-align:center">
                                                        <input type="submit" value="Submit" class="btn btn-primary bttnns">
                                                     </td>
                                                </tr>
                                            </table>
                                        </form>
                			</div>
                		</div>		
                	</div>
                </section>
            </div>
          </div>
        </div>
      </div>

//JS FILES
<script src="js/jquery.min.js"></script> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/swiper.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/jquery.stellar.js"></script> 
<script src="js/isotope.min.js"></script> 
<script src="js/scripts.js"></script> 
<script src="js/viewer.js"></script> 
<script src="js/jquery-viewer.js"></script> 
<script src="js/main.js"></script> 
<script src="js/jquery.cookie.min.js"></script>
<script src="js/form-scripts.js"></script>
-->

</body>
</html> <div class="banner">
	<img src="images/internet-marketing.jpg">
</div>
<!-- content_section -->
<section class="content">
	<div class="container">	
		<div class="row">
			<div class="col-md-9 col-sm-9">
				<h1>Digital Marketing</h1>
				<p>A website is directly submitted to any search engine in this process of Search Engine Submission. This process is successfully handled by a webmaster as a method of boosting the rankings of a website. With the direct submission of the website, a new result or rating to the website is being added and so one need not wait till the site is being discovered by the search engines. Moreover, through search engine submission all the updations or modifications made in the website are captured by the search engines.</p>
				</br>
				<p>With such an immediate effect, businesses are looking after to go for Search Engine Submission services. And for their facility, they need not search long for an efficient service provider. Your search ends here for that reason, as we at our eWeb Services Company provide you with effective Search Engine Submission services.</p>
				</br>
				<p>The eWeb Services professionals are dedicated in helping our clients business grow on a fast pase. Growth of a business is not confined till providing quality product and services rather it need result oriented promotions and advertisement to the potential user. We ensure you to have such result oriented Search Engine Submission and Search Engine optimization services. We have designed wide range of activities to help our client’s business securing the top places at major search engines such as Bing, Yahoo, Google etc and boosting up their website’s traffic.</p>									
				</br>
				<p><strong>Digital marketing have two types:</strong></p>
				
				<ul>
				    <li>Google Adwords (Pay Per Click - PPC) - Name of this service describe it, Pay Per Click. It is paid a service from Google. </li>
				    <li>SEO (Search Engine Optimization) - Which shows organic ranking of your website in Google. This is free, Google don't charge for these services.</li>
				</ul>
				</br>
				<section class="top_section">
                	<div class="container">		
                		<div class="col-md-8 text-center">
                			<h1>You have project and want to discuss with us ?</h1>
                			<a class="btn btn-warning danbtn" href="contactus.php">Request Callback</a>
                		</div>					
                	</div>
                </section>
				</br>
			</div>
			
			<div class="col-md-3 col-sm-3">
				 <!DOCTYPE html>
<html lang="en">
<head>
<title>Internet Marketing</title>
</head>
<body>
																				
		<div class="leftside">
			<h3>Our Services</h3>
			<ul class="serv_list">
				<li><a href="website-design.php"><i class="fa fa-chevron-circle-right"></i> Website Designing</a></li>
				<li><a href="web-development.php"><i class="fa fa-chevron-circle-right"></i> Web Development</a></li>
				<li><a href="wordpress-development.php"><i class="fa fa-chevron-circle-right"></i> Wordpress Development</a></li>
				<li><a href="ecommerce-solutions.php"><i class="fa fa-chevron-circle-right"></i> Ecommerce Solutions</a></li>
				<!--<li class="spcial"><a href="special-website-offers.php"><i class="fa fa-chevron-circle-right"></i> Special Website Offers</a></li>-->
				<li><a href="mobile-apps-development.php"><i class="fa fa-chevron-circle-right"></i> Mobile Apps Development</a></li>
				<li><a href="digital-marketing.php"><i class="fa fa-chevron-circle-right"></i> Digital Marketing</a></li>
				<li class="bordn"><a href="web-hosting.php"><i class="fa fa-chevron-circle-right"></i> Web Hosting</a></li>
			</ul>
		</div>	
					
</body>
</html> 		
			</div>
			
			<div class="col-md-12 packg">												
					<h3>Our SEO Packages</h3>									                  
			    <div class="row">
					<div class="col-xs-12 col-sm-2 col-md-2">
						<div class="db-wrapper">
							<div class="db-pricing-eleven db-bk-color-one">									
								<div class="type">
									Packages
								</div>
								<ul class="key_colr">
									<li><strong>Keywords Plan</strong></li>
									<li><strong>Price Per Month</strong></li>
									<li><strong>Keywords Top 10</strong></li>
								</ul>
								
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-2 col-md-2">
						<div class="db-wrapper">
							<div class="db-pricing-eleven db-bk-color-two popular">									
								<div class="type">
									Basic
								</div>
								<ul>
									<li>10 Keywords</li>
									<li>USD 125</li>
									<li>5</li>
								</ul>
								
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-2 col-md-2">
						<div class="db-wrapper">
							<div class="db-pricing-eleven db-bk-color-three">									
								<div class="type">
									Standard
								</div>
								<ul>
									<li>20 Keywords</li>
									<li>USD 225</li>
									<li>10</li>
								</ul>
								
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-2 col-md-2">
						<div class="db-wrapper">
							<div class="db-pricing-eleven db-bk-color-six">									
								<div class="type">
									Premium
								</div>
								<ul>
									<li> 30 Keywords</li>
									<li>USD 350</li>
									<li>20</li>
								</ul>
								
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-2 col-md-2">
						<div class="db-wrapper">
							<div class="db-pricing-eleven db-bk-color-six">									
								<div class="type">
									Business
								</div>
								<ul>
									<li> 40 Keywords</li>
									<li>USD 425</li>
									<li>30</li>
								</ul>
								
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-2 col-md-2">
						<div class="db-wrapper">
							<div class="db-pricing-eleven db-bk-color-six">									
								<div class="type">
									Platinum
								</div>
								<ul>
									<li>80 Keywords</li>
									<li>USD 750</li>
									<li>60</li>
								</ul>								
							</div>
						</div>
					</div>
				</div>
				
				<h2>Time Frame to achieve 1st page ranking:</h2>
				<ul class="listes">
					<li><i class="fa fa-arrow-circle-right"></i> Low Competition keywords: 3-4 Months</li>
					<li><i class="fa fa-arrow-circle-right"></i> Competition keywords: 5-7 Months</li>
					<li><i class="fa fa-arrow-circle-right"></i> Highly Competition keywords: 8-12 Months</li>
				</ul>
			</div>
	</div>
</section>
<!--// top_section -->
 <!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>

<!-- footer -->
<footer>
	<div class="container">
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Quick Link</h3>
				<ul class="foot_link">
					<li><a href="about-us.php"><i class="fa fa-angle-right"></i> About Us</a></li>
					<li><a href="portfolio.php"><i class="fa fa-angle-right"></i> Portfolio</a></li>
					<li><a href="privacy-policy.php"><i class="fa fa-angle-right"></i> Privacy Policy</a></li>
					<li><a href="contactus.php"><i class="fa fa-angle-right"></i> Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Contact Details</h3>
				<ul class="foot_link">
				    <li><strong>INDIA OFFICE</strong></li>
					<li><i class="fa fa-home"></i> A-16 Sector-9 Noida U.P. -201301, INDIA</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
					<br>
					<li><strong>US OFFICE</strong></li>
					<li><i class="fa fa-home"></i> 20 Days Ave selden NY 12784</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i> +1-631-965-9106</a></li>
					
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Web Services</h3>
				<ul class="foot_link">
					<li><a href="website-design.php"><i class="fa fa-angle-right"></i> Website Designing</a></li>
					<li><a href="web-development.php"><i class="fa fa-angle-right"></i> Web Development</a></li>
					<li><a href="wordpress-development.php"><i class="fa fa-angle-right"></i> Wordpress Development</a></li>
					<li><a href="ecommerce-solutions.php"><i class="fa fa-angle-right"></i> Ecommerce Solutions</a></li>
					<li><a href="mobile-apps-development.php"><i class="fa fa-angle-right"></i> Mobile Apps Development</a></li>
					<li><a href="digital-marketing.php"><i class="fa fa-angle-right"></i> Digital Marketing</a></li>
					<li><a href="web-hosting.php"><i class="fa fa-angle-right"></i> Web Hosting</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Connect With Us</h3>
				<ul class="social_link">
					<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
					<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>Copyright <i class="fa fa-copyright"></i> 2020 <a href="http://www.ewebservices.co.uk/">eWeb Services</a> All rights reserved</p>
		</div>
	</div>
</footer>
<!--// footer -->
<!-- js -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
	(function( $ ) {

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#carousel-example-generic'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
    $('#carousel-example-generic').carousel({
        interval:3000,
        pause: "false"
    });
	
})(jQuery);	
</script>

<a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" title="" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>

<script>
  $(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});
</script>

</body>
</html> </body>
</html> 
 <!DOCTYPE html>
<html lang="en">
<head>
<title>About Us - eWeb Services Pvt. Ltd.</title>

</head>
<body>
 <!DOCTYPE html>
<html lang="en">
<head>
<title>eWeb Services Pvt. Ltd.</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Archivo:400,400i,500,600,700" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="css/plan.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<header>
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 phone">
					<a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a>
				</div>
				<div class="col-md-4 col-sm-4 email">
					<a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="top_social">
						<ul>
							<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
							<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						</button>
					   <div class="logo"><a href="index.php"><img src="images/logo.png" alt="logo"></a></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.php">Home</a></li>
							<li><a href="about-us.php">About Us</a></li>
								<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services 
									<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="website-design.php">Website Designing</a></li>
										<li><a href="web-development.php">Web Development</a></li>
										<li><a href="wordpress-development.php">Wordpress Development</a></li>
										<li><a href="ecommerce-solutions.php">Ecommerce Solutions</a></li>
										<!--<li class="spcial"><a href="special-website-offers.php">Special Website Offers</a></li>-->
										<li><a href="mobile-apps-development.php">Mobile Apps Development</a></li>
																				
										<li><a href="digital-marketing.php">Digital Marketing</a></li>
										<li class="bordn"><a href="web-hosting.php">Web Hosting</a></li>
									</ul>					
								</li>
							<li><a href="portfolio.php">Portfolio</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3">
					<div class="anm_boxx">
						<a href="contactus.php">Request Callback</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
</header>

<!--
<div class="modal fade show in" id="myModal1" role="dialog" aria-modal="true">
  <div class="modal-dialog"> 
    <div class="modal-content">
      <div class="modal-body inq-form">
        <button type="button" class="close btn-white" data-dismiss="modal">×</button>
              <section class="content">
                	<div class="container">
                		<div class="row">
                			<div class="col-md-6 col-sm-6 contt">
                				<h2>Get in Touch With us</h2>
                                        <form name="contactform" method="post" action="contact.php">
                                            <table width="100%">
                                                 <tr>
                                                     <td valign="top">
                                                        <label for="name">Name *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="name" maxlength="50" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="email">Email *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="email" maxlength="80" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                         <label for="phone">Phone *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="phone" maxlength="30" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="comments">Message *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <textarea  name="message" maxlength="1000" cols="25" rows="6" required></textarea>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td colspan="2" style="text-align:center">
                                                        <input type="submit" value="Submit" class="btn btn-primary bttnns">
                                                     </td>
                                                </tr>
                                            </table>
                                        </form>
                			</div>
                		</div>		
                	</div>
                </section>
            </div>
          </div>
        </div>
      </div>

//JS FILES
<script src="js/jquery.min.js"></script> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/swiper.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/jquery.stellar.js"></script> 
<script src="js/isotope.min.js"></script> 
<script src="js/scripts.js"></script> 
<script src="js/viewer.js"></script> 
<script src="js/jquery-viewer.js"></script> 
<script src="js/main.js"></script> 
<script src="js/jquery.cookie.min.js"></script>
<script src="js/form-scripts.js"></script>
-->

</body>
</html> <div class="banner">
	<img src="images/aboutt-us.jpg">
</div>
<!-- content_section -->

<section class="content">
	<div class="container">	
		<div class="row">
			<div class="col-md-12">
				<h1>Welcome To eWeb Services Pvt. Ltd.</h1>
				<p>eWeb Services Pvt. Ltd. provide design and develop intelligence for you business growth. A one place where you websites can be designed, developed and optimized with the implementation of best strategies suiting to your business type.</p>
				<p>Before beginning with the solution, we carry out a brain storming session with our, for a detailed study about their business or services provided by them. Discussion about their requirements and desired results i.e. expected traffic and visibility of their website. Special attention is given to our clients.</p>
				
				<p>We then bring together justified combination of design, technology, SEO strategies and last but not the least our experiences.</p>
				
				<p>We tend to choose, latest best and fruit earning technology. We believe in working with proficiency, learning new advancements, making our team grow with time.</p>

				
				<p>Established in 2007, we have got 10-20 dynamic professionals with us who are self motivated and humorous to be as well.</p>
				<p>We aim at providing you with profit earning affordable and quality solution.</p>
				
			</div>
			
			<div class="col-md-12">
				<h2>Our Technical Team Expert</h2>
				<div class="progress margp">
				  <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar"
				  aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:95%">
					95% Web Design
				  </div>
				</div>

				<div class="progress">
				  <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar"
				  aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:90%">
					90% Web Development
				  </div>
				</div>
				
				<div class="progress margp">
				  <div class="progress-bar progress-bar-primary progress-bar-striped" role="progressbar"
				  aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:75%">
					75% Mobile Apps Development
				  </div>
				</div>

				<div class="progress">
				  <div class="progress-bar progress-bar-warning progress-bar-striped" role="progressbar"
				  aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:80%">
					80% Wordpress
				  </div>
				</div>

				<div class="progress">
				  <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar"
				  aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:85%">
					85% Internet Marketing
				  </div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--// top_section -->
 <!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>

<!-- footer -->
<footer>
	<div class="container">
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Quick Link</h3>
				<ul class="foot_link">
					<li><a href="about-us.php"><i class="fa fa-angle-right"></i> About Us</a></li>
					<li><a href="portfolio.php"><i class="fa fa-angle-right"></i> Portfolio</a></li>
					<li><a href="privacy-policy.php"><i class="fa fa-angle-right"></i> Privacy Policy</a></li>
					<li><a href="contactus.php"><i class="fa fa-angle-right"></i> Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Contact Details</h3>
				<ul class="foot_link">
				    <li><strong>INDIA OFFICE</strong></li>
					<li><i class="fa fa-home"></i> A-16 Sector-9 Noida U.P. -201301, INDIA</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
					<br>
					<li><strong>US OFFICE</strong></li>
					<li><i class="fa fa-home"></i> 20 Days Ave selden NY 12784</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i> +1-631-965-9106</a></li>
					
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Web Services</h3>
				<ul class="foot_link">
					<li><a href="website-design.php"><i class="fa fa-angle-right"></i> Website Designing</a></li>
					<li><a href="web-development.php"><i class="fa fa-angle-right"></i> Web Development</a></li>
					<li><a href="wordpress-development.php"><i class="fa fa-angle-right"></i> Wordpress Development</a></li>
					<li><a href="ecommerce-solutions.php"><i class="fa fa-angle-right"></i> Ecommerce Solutions</a></li>
					<li><a href="mobile-apps-development.php"><i class="fa fa-angle-right"></i> Mobile Apps Development</a></li>
					<li><a href="digital-marketing.php"><i class="fa fa-angle-right"></i> Digital Marketing</a></li>
					<li><a href="web-hosting.php"><i class="fa fa-angle-right"></i> Web Hosting</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Connect With Us</h3>
				<ul class="social_link">
					<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
					<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>Copyright <i class="fa fa-copyright"></i> 2020 <a href="http://www.ewebservices.co.uk/">eWeb Services</a> All rights reserved</p>
		</div>
	</div>
</footer>
<!--// footer -->
<!-- js -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
	(function( $ ) {

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#carousel-example-generic'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
    $('#carousel-example-generic').carousel({
        interval:3000,
        pause: "false"
    });
	
})(jQuery);	
</script>

<a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" title="" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>

<script>
  $(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});
</script>

</body>
</html> </body>
</html> 
 <!DOCTYPE html>
<html lang="en">
<head>
<title>Mobile Apps Development Services INDIA, Delhi</title>
</head>
<body>
 <!DOCTYPE html>
<html lang="en">
<head>
<title>eWeb Services Pvt. Ltd.</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css"/>
<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Archivo:400,400i,500,600,700" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="css/plan.css" type="text/css" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<header>
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 phone">
					<a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a>
				</div>
				<div class="col-md-4 col-sm-4 email">
					<a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="top_social">
						<ul>
							<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
							<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						</ul>	
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span> 
						</button>
					   <div class="logo"><a href="index.php"><img src="images/logo.png" alt="logo"></a></div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="collapse navbar-collapse" id="myNavbar">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.php">Home</a></li>
							<li><a href="about-us.php">About Us</a></li>
								<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services 
									<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="website-design.php">Website Designing</a></li>
										<li><a href="web-development.php">Web Development</a></li>
										<li><a href="wordpress-development.php">Wordpress Development</a></li>
										<li><a href="ecommerce-solutions.php">Ecommerce Solutions</a></li>
										<!--<li class="spcial"><a href="special-website-offers.php">Special Website Offers</a></li>-->
										<li><a href="mobile-apps-development.php">Mobile Apps Development</a></li>
																				
										<li><a href="digital-marketing.php">Digital Marketing</a></li>
										<li class="bordn"><a href="web-hosting.php">Web Hosting</a></li>
									</ul>					
								</li>
							<li><a href="portfolio.php">Portfolio</a></li>
							<li><a href="contactus.php">Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3">
					<div class="anm_boxx">
						<a href="contactus.php">Request Callback</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
</header>

<!--
<div class="modal fade show in" id="myModal1" role="dialog" aria-modal="true">
  <div class="modal-dialog"> 
    <div class="modal-content">
      <div class="modal-body inq-form">
        <button type="button" class="close btn-white" data-dismiss="modal">×</button>
              <section class="content">
                	<div class="container">
                		<div class="row">
                			<div class="col-md-6 col-sm-6 contt">
                				<h2>Get in Touch With us</h2>
                                        <form name="contactform" method="post" action="contact.php">
                                            <table width="100%">
                                                 <tr>
                                                     <td valign="top">
                                                        <label for="name">Name *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="name" maxlength="50" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="email">Email *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="email" maxlength="80" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                         <label for="phone">Phone *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <input  type="text" name="phone" maxlength="30" size="30" required>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td valign="top">
                                                        <label for="comments">Message *</label>
                                                     </td>
                                                     <td valign="top">
                                                        <textarea  name="message" maxlength="1000" cols="25" rows="6" required></textarea>
                                                     </td>
                                                </tr>
                                                <tr>
                                                     <td colspan="2" style="text-align:center">
                                                        <input type="submit" value="Submit" class="btn btn-primary bttnns">
                                                     </td>
                                                </tr>
                                            </table>
                                        </form>
                			</div>
                		</div>		
                	</div>
                </section>
            </div>
          </div>
        </div>
      </div>

//JS FILES
<script src="js/jquery.min.js"></script> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/swiper.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/jquery.stellar.js"></script> 
<script src="js/isotope.min.js"></script> 
<script src="js/scripts.js"></script> 
<script src="js/viewer.js"></script> 
<script src="js/jquery-viewer.js"></script> 
<script src="js/main.js"></script> 
<script src="js/jquery.cookie.min.js"></script>
<script src="js/form-scripts.js"></script>
-->

</body>
</html> <div class="banner">
	<img src="images/mobile-apps.jpg">
</div>
<!-- content_section -->

<section class="content">
	<div class="container">	
		<div class="row">
			<div class="col-md-9 col-sm-9 mobilap">
				<h1>Mobile Apps Development</h1>
				<p>It is crystal clear that the demand of mobile apps has escalated in all businesses. To cope with that, we become your accelerator to design and develop brilliant mobile applications. 360 Degree eWeb Services is a top-notch mobile app development company offering mobile application development services for iPhone, iPad and Android.</p>
				</br>				
				<p>Our team of mobile app developers is creative and knowledgeable to accomplish your individual demands as well as your business needs. With advanced tools and technology our mobile apps developers are able to create highly customized mobile applications for consumer needs and enterprises. Our experience and past work is the showcase of our brilliance in mobile applications development.</p>
				
				<h2>Mobile Apps Development Services We Offer:</h2>
				<h3>iPhone Application Development</h3>
				
				<p>With the advent of iOS technological advancements, we build elegant and engaging iPhone applications that will not only make your business lucrative but also performance oriented. Our professional iPhone application developers always design and develop user-friendly and easy-to-use mobile apps.</p>		
				
				<h3>iPad App Development</h3>
				<p>With a view to make your iPad apps high-yielding, our expert delivers the superior quality of applications. We will make your iPad apps idea tops the chart by executing it accordingly. We exhibit our tenacity by making completely bug-free iPad apps.</p>
				
				<h3>Android App Development</h3>
				<p>Be it social media, restaurants, health care, sports, education sector, etc., we design and develop every type of Android Apps for smart phones and tablets. Our Android developers are passionate and professional in crafting the highest quality mobile application for you.</p>
				</br>
				<section class="top_section">
                	<div class="container">		
                		<div class="col-md-8 text-center">
                			<h1>You have project and want to discuss with us ?</h1>
                			<a class="btn btn-warning danbtn" href="contactus.php">Request Callback</a>
                		</div>					
                	</div>
                </section>
				</br>
				<div class="tablem">															
					<div class="col-md-12 contmg">	
						<h3 class="titles"><u><a href="contactus.html">Contact us</a></u> and send us the following requirements for a mobile app development:</h3>
						<ul class="listes">
							<li><i class="fa fa-arrow-circle-right"></i> What is the purpose of the app?</li>
							<li><i class="fa fa-arrow-circle-right"></i> What are you trying to accomplish?</li>
							<li><i class="fa fa-arrow-circle-right"></i> What should the app be able to do (ie. functionality)?</li>
							<li><i class="fa fa-arrow-circle-right"></i> Are there branding and design guidelines that need to be followed?</li>
							<li><i class="fa fa-arrow-circle-right"></i> What platforms will the app be built for (iOS, Android, etc)?</li>
							<li><i class="fa fa-arrow-circle-right"></i> Do you have current API/services documentation?</li>
							<li><i class="fa fa-arrow-circle-right"></i> Do you have current Apple, Google, or other developer accounts/credentials?</li>
							<li><i class="fa fa-arrow-circle-right"></i> Do you already have website?</li>
							<li><i class="fa fa-arrow-circle-right"></i> Do you have any reference website?</li>
						</ul>																			
					</div>
				</div>
			</div>
			
			<div class="col-md-3 col-sm-3">
				 <!DOCTYPE html>
<html lang="en">
<head>
<title>Internet Marketing</title>
</head>
<body>
																				
		<div class="leftside">
			<h3>Our Services</h3>
			<ul class="serv_list">
				<li><a href="website-design.php"><i class="fa fa-chevron-circle-right"></i> Website Designing</a></li>
				<li><a href="web-development.php"><i class="fa fa-chevron-circle-right"></i> Web Development</a></li>
				<li><a href="wordpress-development.php"><i class="fa fa-chevron-circle-right"></i> Wordpress Development</a></li>
				<li><a href="ecommerce-solutions.php"><i class="fa fa-chevron-circle-right"></i> Ecommerce Solutions</a></li>
				<!--<li class="spcial"><a href="special-website-offers.php"><i class="fa fa-chevron-circle-right"></i> Special Website Offers</a></li>-->
				<li><a href="mobile-apps-development.php"><i class="fa fa-chevron-circle-right"></i> Mobile Apps Development</a></li>
				<li><a href="digital-marketing.php"><i class="fa fa-chevron-circle-right"></i> Digital Marketing</a></li>
				<li class="bordn"><a href="web-hosting.php"><i class="fa fa-chevron-circle-right"></i> Web Hosting</a></li>
			</ul>
		</div>	
					
</body>
</html> 		
			</div>
		</div>
	</div>
</section>
<!--// top_section -->
 <!DOCTYPE html>
<html lang="en">
<head>

</head>
<body>

<!-- footer -->
<footer>
	<div class="container">
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Quick Link</h3>
				<ul class="foot_link">
					<li><a href="about-us.php"><i class="fa fa-angle-right"></i> About Us</a></li>
					<li><a href="portfolio.php"><i class="fa fa-angle-right"></i> Portfolio</a></li>
					<li><a href="privacy-policy.php"><i class="fa fa-angle-right"></i> Privacy Policy</a></li>
					<li><a href="contactus.php"><i class="fa fa-angle-right"></i> Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Contact Details</h3>
				<ul class="foot_link">
				    <li><strong>INDIA OFFICE</strong></li>
					<li><i class="fa fa-home"></i> A-16 Sector-9 Noida U.P. -201301, INDIA</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i>+91-959-974-1924</a></li>
					<li><a href="mailto:info@ewebservices.co.uk"><i class="fa fa-envelope"></i> info@ewebservices.co.uk</a></li>
					<br>
					<li><strong>US OFFICE</strong></li>
					<li><i class="fa fa-home"></i> 20 Days Ave selden NY 12784</li>
					<li><a href="tel:+91-959-974-1924"><i class="fa fa-mobile"></i> +1-631-965-9106</a></li>
					
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Web Services</h3>
				<ul class="foot_link">
					<li><a href="website-design.php"><i class="fa fa-angle-right"></i> Website Designing</a></li>
					<li><a href="web-development.php"><i class="fa fa-angle-right"></i> Web Development</a></li>
					<li><a href="wordpress-development.php"><i class="fa fa-angle-right"></i> Wordpress Development</a></li>
					<li><a href="ecommerce-solutions.php"><i class="fa fa-angle-right"></i> Ecommerce Solutions</a></li>
					<li><a href="mobile-apps-development.php"><i class="fa fa-angle-right"></i> Mobile Apps Development</a></li>
					<li><a href="digital-marketing.php"><i class="fa fa-angle-right"></i> Digital Marketing</a></li>
					<li><a href="web-hosting.php"><i class="fa fa-angle-right"></i> Web Hosting</a></li>
				</ul>
			</div>
		</div>
		<div class="col-md-3 col-sm-3">
			<div class="foot_sectn">
				<h3>Connect With Us</h3>
				<ul class="social_link">
					<li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
					<li><a href="https://twitter.com/eweb_services"><i class="fa fa-twitter" target="_blank"></i></a></li>
					<li><a href="https://www.linkedin.com/in/eweb-services-8173a8144/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="copyright">
		<div class="container">
			<p>Copyright <i class="fa fa-copyright"></i> 2020 <a href="http://www.ewebservices.co.uk/">eWeb Services</a> All rights reserved</p>
		</div>
	</div>
</footer>
<!--// footer -->
<!-- js -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
	(function( $ ) {

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#carousel-example-generic'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
    $('#carousel-example-generic').carousel({
        interval:3000,
        pause: "false"
    });
	
})(jQuery);	
</script>

<a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" title="" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>

<script>
  $(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});
</script>

</body>
</html> 
</body>
</html> 